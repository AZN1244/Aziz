4D Payments SDK 2016 C++ Edition Usage and Deployment Instructions

This file includes information on using and deploying the libraries included 
in the toolkit. 

****************************************
*       Installation and Usage         *
****************************************

To install the toolkit extract dpaymentssdk-16.0.tar.gz. For instance:

    tar -xf dpaymentssdk-16.0.tar.gz
  
The libraries are included as shared object libraries (libdpaymentssdk.so.16.0) 
and are present as both 32-bit and 64-bit versions. These libraries may be 
found in the "lib\linux" and "lib64\linux" directories of the installation.

The libraries do not need to be installed to /lib or any other location to use
them. The makefiles included with the demos in the "demos" folder use rpath to
link the libraries. 

If you do wish to install the libraries to "/lib" for ease of use an example 
follows: 

    #Add .so to /lib (if desired - not required)
    sudo cp dpaymentssdk-16.0/lib64/linux/libdpaymentssdk.so.16.0 /lib/
    sudo ln -s /lib/libdpaymentssdk.so.16.0 /lib/libdpaymentssdk.so.16
    sudo ln -s /lib/libdpaymentssdk.so.16.0 /lib/libdpaymentssdk16.so
    sudo ln -s /lib/libdpaymentssdk.so.16.0 /lib/libdpaymentssdk.so

    
****************************************
*          Trial Licensing             *
****************************************

Visit the URL below to generate a 30-day Trial Runtime License value.

    https://www.4dpayments.com/trial/BCCBA

After obtaining the Runtime License value assign this to the RuntimeLicense
property to license the application for deployment. For instance:

    component.SetRuntimeLicense("value from above")

This provides a 30-day trial license to the component and your application
will run without a license prompt on any machine to which it is distributed
during that time. 

Note that each component instance in your code must be assigned a 
Runtime License value.
  
****************************************
*   Limited Distribution Licensing     *
****************************************

Visit the URL below to generate a Runtime License value.

    https://www.4dpayments.com/full/BCCBA

After obtaining the Runtime License value assign this to the RuntimeLicense
property to license the application for deployment. For instance:

    component.SetRuntimeLicense("value from above")

This provides a license to the component and your application will run without
a license prompt on any machine to which it is distributed. 

Note that each component instance in your code must be assigned a 
Runtime License value.
  
****************************************
*       Single Server Licensing        *
****************************************

Single server licenses require the license to be activated on the system where
the components will be used. To activate a single server license visit the URL
below

	https://www.4dpayments.com/full/BCCBA

You will be prompted to download and run an executable "install-license" 
application.
  
The single server license will be downloaded and stored in the ".DPayments" 
folder of the user's home directory (i.e. "~/.DPayments").

At runtime a valid license must be present in either the current directory or
the ".DPayments" folder of the user's home directory.

